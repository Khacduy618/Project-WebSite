<?php
    //Phần 1 bài 1
    echo "Hello <br>";
    echo ("Hello <br>");
    echo "Hello World <br>";
    echo "Hello","World";
    //bài 2
    $str="hello string";
    $x=2;
    $y=44.6;
    echo "string is: $str <br/>";
    echo "integer is: $x <br/>";
    echo "float is: $y <br/>";
    //bài 3
    $color="red";
    $COLOR="yellow";
    $coLOR="blue";
    echo "My car is " . $color . "<br>";
    echo "My house is " . $COLOR . "<br>";
    echo "My boat is " . $coLOR . "<br>";
    //Phần 2 bài 1
    $x = (2 == 3); //equal to (false)
    $x = (2 != 3); //not equal to (true)
    $x = (2 <> 3); //not equal to (alternative)
    $x = (2 === 3); //identical (false)
    $x = (2 !== 3); //not identical (true)
    $x = (2 > 3); //false, greater than (false)
    $x = (2 < 3); //less than (true)
    $x = (2 >= 3); //greater than or equal to (false)
    $x = (2 <= 3); //less than or equal to(true)
    //bài 2

    //bài 3
    $a = 2;
    $b = 3;
    $sum = $a + $b;
    echo " Tính tổng 2 số tự nhiên a và b: Tong 2 so $a va $b la $sum";
?>