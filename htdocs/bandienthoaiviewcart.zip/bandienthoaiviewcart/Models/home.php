<?php
require_once("model.php");
class Home extends Model
{
    
}