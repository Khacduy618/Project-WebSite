<?php
require_once("model.php");

class Danhmuc extends Model
{
    var $table = "danhmuc";
    var $contens = "MaDM";
}
