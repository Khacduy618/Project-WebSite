<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <h2>Title: <?= $data['MaDM'] ?></h2>
    <h2>Title: <?= $data['TenDM'] ?></h2>
</table>