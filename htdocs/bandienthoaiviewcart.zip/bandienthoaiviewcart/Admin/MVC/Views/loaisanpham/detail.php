<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <h2>Mã LSP: <?= $data['MaLSP'] ?></h2>
    <h2>Tên LSP: <?= $data['TenLSP'] ?></h2>
    <h2>Hình ảnh: <img src="../public/img/company/<?= $data['HinhAnh'] ?>" height="60px"></h2>
    <h2>Mô tả: <?= $data['Mota'] ?></h2>
    <h2>Mã danh mục: <?= $data['MaDM'] ?></h2>
</table>